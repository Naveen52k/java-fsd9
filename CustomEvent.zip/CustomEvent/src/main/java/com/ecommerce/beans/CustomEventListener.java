package com.ecommerce.beans;

import com.custom.CustomEvent;

public class CustomEventListener {
	
	   public void onApplicationEvent(CustomEvent event) {
		      System.out.println(event.toString());
		   }


}
