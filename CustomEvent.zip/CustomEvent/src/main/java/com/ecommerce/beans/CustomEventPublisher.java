package com.ecommerce.beans;

import org.springframework.context.ApplicationEventPublisher;

import com.custom.CustomEvent;

public class CustomEventPublisher {
	
	   private ApplicationEventPublisher publisher;
	public void setApplicationEventPublisher (ApplicationEventPublisher publisher) {
		      this.publisher = publisher;
		   }
		   public void publish() {
		      CustomEvent ce = new CustomEvent(this);
		      publisher.publishEvent(ce);
		   }


}
