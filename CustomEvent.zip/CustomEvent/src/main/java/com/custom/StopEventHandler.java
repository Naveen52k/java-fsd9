package com.custom;

import org.springframework.context.event.ContextStoppedEvent;

public class StopEventHandler {
	
	public void onApplicationEvent(ContextStoppedEvent event) {
        System.out.println("ContextStoppedEvent Received");
     }


}
