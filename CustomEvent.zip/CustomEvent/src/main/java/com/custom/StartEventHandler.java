package com.custom;

import org.springframework.context.event.ContextStartedEvent;

public class StartEventHandler {
	
	public void onApplicationEvent(ContextStartedEvent event) {
        System.out.println("ContextStartedEvent Received");
     }


}
