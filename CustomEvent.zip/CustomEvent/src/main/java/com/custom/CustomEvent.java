package com.custom;

public class CustomEvent {
	
    public CustomEvent(Object source) {
  super();
}
public String toString(){
  return "This is a custom event";
}


}
